MetricMiner
===========

MetricMiner is an application for supporting studies at Mining Software Repositories, currently avaiable at http://metricminer.org.br/. 

This tool stores data from git and SVN repositories and calculates source code metrics over the history of the projects. After mining the source code repository, the user can query the mined data through SQL queries.

License
-------

This software can be downloaded for non-profit educational and 
research purposes under the GPL v3 license. 

For commercial use of this software, contact the authors to 
negotiate a specific license.

This app was developed as a undergraduate conclusion project at IME-USP (Institute of Mathematics and Statistics University of São Paulo).
