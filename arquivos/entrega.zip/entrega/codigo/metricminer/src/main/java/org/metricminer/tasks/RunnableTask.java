package org.metricminer.tasks;

public interface RunnableTask {

	public void run();
}
