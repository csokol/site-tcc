package org.metricminer.model;

public enum ModificationKind {

	NEW,
	DELETED ,
	DEFAULT;
	
}
