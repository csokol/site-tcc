package org.metricminer.tasks.metric.common;

public interface MetricResult {

}
