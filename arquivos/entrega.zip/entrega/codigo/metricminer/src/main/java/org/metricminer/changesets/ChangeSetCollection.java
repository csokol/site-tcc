package org.metricminer.changesets;

import java.util.List;

public interface ChangeSetCollection {
	List<ChangeSet> get();
}
