package org.metricminer.scm;

public class SCMException extends RuntimeException {

	public SCMException(Exception e) {
		super(e);
	}

	private static final long serialVersionUID = 1L;

}
