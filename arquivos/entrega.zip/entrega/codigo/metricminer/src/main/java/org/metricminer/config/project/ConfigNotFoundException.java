package org.metricminer.config.project;

public class ConfigNotFoundException extends RuntimeException {

	public ConfigNotFoundException(String message) {
		super(message);
	}

	private static final long serialVersionUID = 1L;

}
