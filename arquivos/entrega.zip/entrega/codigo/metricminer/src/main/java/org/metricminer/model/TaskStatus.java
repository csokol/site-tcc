package org.metricminer.model;

public enum TaskStatus {
	FINISHED, STARTED, QUEUED, FAILED;
}
