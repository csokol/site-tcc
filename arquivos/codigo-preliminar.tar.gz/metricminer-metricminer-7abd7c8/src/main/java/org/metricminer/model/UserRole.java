package org.metricminer.model;

public enum UserRole {
	RESEARCHER, ADMINISTRATOR;
}
