package org.metricminer.config.project;

public class Configs {
	public static final String SCM = "scm";
	public static final String BUILD = "build";
	public static final String CHANGESETS = "changesets"; 
}
