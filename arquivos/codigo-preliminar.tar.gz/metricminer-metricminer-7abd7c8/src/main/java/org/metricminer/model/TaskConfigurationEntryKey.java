package org.metricminer.model;

public enum TaskConfigurationEntryKey {
    METRIC_FACTORY_CLASS, QUERY_ID, PROJECT_METRIC_FACTORY_CLASS,
}
