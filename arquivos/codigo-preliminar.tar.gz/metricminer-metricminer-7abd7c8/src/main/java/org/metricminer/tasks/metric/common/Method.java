package org.metricminer.tasks.metric.common;

public class Method {

	private String name;
	private int lines;
	public Method(String name, int lines) {
		this.name = name;
		this.lines = lines;
	}
	public String getName() {
		return name;
	}
	public int getLines() {
		return lines;
	}
	
	
	
	
}
