package org.metricminer.model;

public enum ArtifactKind {
	CODE,
	BINARY
}
