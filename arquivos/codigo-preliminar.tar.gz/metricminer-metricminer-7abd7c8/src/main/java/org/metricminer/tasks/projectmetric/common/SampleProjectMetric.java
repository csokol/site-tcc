package org.metricminer.tasks.projectmetric.common;

import java.util.List;

import org.metricminer.tasks.metric.common.MetricResult;

public class SampleProjectMetric implements ProjectMetric {

    @Override
    public List<MetricResult> calculate() {
        return null;
    }

}
