package org.metricminer.tasks.metric.common;

public interface MetricFactory {

    public Metric build();
}
