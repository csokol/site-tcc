package org.metricminer.scm;

public class SCMNotFoundException extends RuntimeException {

	private static final long serialVersionUID = 1L;

}
