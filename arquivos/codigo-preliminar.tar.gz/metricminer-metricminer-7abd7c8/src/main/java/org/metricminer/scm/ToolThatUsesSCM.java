package org.metricminer.scm;

public interface ToolThatUsesSCM {
	void setSCM(SCM scm);
}
